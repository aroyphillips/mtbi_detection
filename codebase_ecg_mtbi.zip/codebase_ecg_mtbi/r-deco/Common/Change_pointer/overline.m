function overline(hFigure, currentPoint) %#ok

% Change pointer to 'left'
set(hFigure, 'Pointer', 'left');
