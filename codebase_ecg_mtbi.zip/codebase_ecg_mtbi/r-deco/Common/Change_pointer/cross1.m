function cross1(hFigure, currentPoint) %#ok

% Change pointer to crosshair
set(hFigure, 'Pointer', 'fleur');