import pandas as pd
import os
import numpy as np
import glob
import antropy as ant

def make_ecg_dict(folder_path ='/Users/joshu/OneDrive/Desktop/aazlab/five_min_ecgs/five_min_ecgs', segment_type = ['eyes_open_','eyes_closed_','ecg_baseline']):
    """
    Desc: Dictionary where keys --> subject id and vals --> dictionary where keys are "open" or "closed" or "five minutes" and vals are a list of rr intervals

    Inputs: 
    folder_path  -->  directory of folders containing ecg data csvs, 
    segment_type --> open, closed, or five minutes

    Outputs: description
    """
    ecg_data = {}
    rpeak_arrays = []

    folder_path = '/Users/.../{s_id}/baseline' #s_id = subject id
    segment_type = ['eyes_open_','eyes_closed_','ecg_baseline']

    # CHANGE THIS WHEN CHANGING SEGMENT TYPES
    seg_type = segment_type[2]

    for s_id in os.listdir(folder_path):
        csv_files = glob.glob(os.path.join(folder_path, '*.csv'))
        for csv_file in csv_files:
            csv_file = csv_file.replace("\\",'/')
            rpeak_array = pd.read_csv(csv_file, usecols = ['RR-interval (ms)']).values
            for seg_types in segment_type:
                if seg_type in csv_file:
                    ecg_data[s_id] = {seg_type: rpeak_array}

    return ecg_data

def calc_mean_rr(rr_array):
    return np.nanmean(rr_array)    

def calc_mean_hr(rr_array):
    return np.nanmean(60000/rr_array)

def calc_max_hr(rr_array):
    return np.nanmax(60000/rr_array)

def calc_min_hr(rr_array):
    return np.nanmin(60000/rr_array)

def calc_std_hr(rr_array):
    return np.nanstd(60000/rr_array)

def calc_hrv(rr_array):
    return np.nanstd(rr_array)

def calc_rmssd(rr_array):
    rr_array = rr_array[~np.isnan(rr_array)]
    return np.sqrt(np.mean(np.square(np.diff(rr_array))))

def calc_pnn50(rr_array):
    rr_array = rr_array[~np.isnan(rr_array)]
    ibi_differences = np.abs(np.diff(rr_array))
    ibi_differences[ibi_differences < 50] = 0
    pnn50 = len(np.nonzero(ibi_differences)[0]) / len(ibi_differences)
    return pnn50

def calc_75_perc(rr_array):
    return np.nanpercentile(rr_array, 75)

def calc_25_perc(rr_array):
    return np.nanpercentile(rr_array, 25)

def calc_iqr(rr_array):
    return calc_75_perc(rr_array) - calc_25_perc(rr_array)

def calc_perm_ent(rr_array):
    return ant.perm_entropy(rr_array, normalize=True)

def calc_spec_ent(rr_array):
    return ant.spectral_entropy(rr_array, sf=500, method='welch', normalize=True)

def calc_svd_ent(rr_array):
    return ant.svd_entropy(rr_array, normalize=True)

def calc_approx_ent(rr_array):
    return ant.app_entropy(rr_array)

def calc_sample_ent(rr_array):
    return ant.sample_entropy(rr_array)

def calc_hjorth_mob(rr_array):
    return ant.hjorth_params(rr_array)[0]

def calc_hjorth_comp(rr_array):
    return ant.hjorth_params(rr_array)[1]

def calc_zero_cross(rr_array):
    return ant.num_zerocross(rr_array)

def get_ecg_features(ecg_data, feature_names = ["mean RR", "mean HR", "max HR", "min HR", "stdev HR", "hrv", "rmssd", "pnn50", "75th percentile", "25th percentile", "iqr",
                                                              "permutation entropy", "spectral entropy", "svd entropy", "approximate entropy", "sample entropy", "hjorth mobility", "hjorth complexity"], \
                     segment_type = 'ecg_baseline' ):
    """
    Desc: makes dictionary where keys are segment types and values are numpy arrays of subject ids x features
    Inputs: 
    ecg_data -> Dictionary where keys --> subject id and vals --> dictionary where keys are "open" or "closed" or "five minutes" and vals are a list of rr intervals
    Outputs: 
    ids_x_feat_dict_array -> dictionary where keys are segment types and values are numpy arrays of subject ids x features
    """
    print("Calculating ECG features")
    subj_ids = np.array(list(ecg_data.keys()))
    seg_types = np.array(list(ecg_data[subj_ids[0]].keys()))
    feature_names = ["mean RR", "mean HR", "max HR", "min HR", "stdev HR", "hrv", "rmssd", "pnn50", "75th percentile", "25th percentile", "iqr",
                    "permutation entropy", "spectral entropy", "svd entropy", "approximate entropy", "sample entropy", "hjorth mobility", "hjorth complexity"] 
    
    # Dictionary where keys are segment types and values are numpy arrays of subject ids x features
    ids_x_feat = [] 
    id_features = []
    for subject_ind,subject_id in enumerate(subj_ids):
        for segment_int,segment_type in enumerate(seg_types):
            
            # Find ibis
            ibi = ecg_data[subject_id][segment_type]
            ibi_array = ibi[~np.isnan(ibi)]
            for feature_ind,feature_type in enumerate(feature_names):
                if feature_type == "mean RR":
                    id_features.append(calc_mean_rr(ibi))
                elif feature_type == "mean HR":
                    id_features.append(calc_mean_hr(ibi))
                elif feature_type == "max HR":
                    id_features.append(calc_max_hr(ibi))
                elif feature_type == "min HR":
                    id_features.append(calc_min_hr(ibi))
                elif feature_type == "stdev HR":
                    id_features.append(calc_std_hr(ibi))
                elif feature_type == "hrv":
                    id_features.append(calc_hrv(ibi))
                elif feature_type == "rmssd":
                    id_features.append(calc_rmssd(ibi))
                elif feature_type == "pnn50":
                    id_features.append(calc_pnn50(ibi))
                elif feature_type == "75th percentile":
                    id_features.append(calc_75_perc(ibi))
                elif feature_type == "25th percentile":
                    id_features.append(calc_25_perc(ibi))
                elif feature_type == "iqr":
                    id_features.append(calc_iqr(ibi))
                elif feature_type == "permutation entropy":
                    id_features.append(calc_perm_ent(ibi_array))
                elif feature_type == "spectral entropy":
                    id_features.append(calc_spec_ent(ibi_array))
                elif feature_type == "svd entropy":
                    id_features.append(calc_svd_ent(ibi_array))
                elif feature_type == "approximate entropy":
                    id_features.append(calc_approx_ent(ibi_array))
                elif feature_type == "sample entropy":
                    id_features.append(calc_sample_ent(ibi_array))
                elif feature_type == "hjorth mobility":
                    id_features.append(calc_hjorth_mob(ibi_array))
                elif feature_type == "hjorth complexity":
                    id_features.append(calc_hjorth_comp(ibi_array))

                    # Add to the list of list of features!
                    ids_x_feat.append(id_features)
                    id_features = []

                else:
                    raise ValueError(f"{feature_type} not defined") 
                
    # Make 3 dataframes of subject ids x feature names based on segment type (the keys)
    ids_x_feat_dict_array = {segment_type: ids_x_feat}
    df_list = []
    df_features = pd.DataFrame(data=ids_x_feat, index=subj_ids, columns=feature_names)
    df_list.append(df_features)
    df_features.to_csv(f"/Users/.../ecg_features/{segment_type}.csv")
    return ids_x_feat_dict_array

