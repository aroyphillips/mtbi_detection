**ECG Feature Extraction**

**Description**
1.  r-deco: Folder containing code for ECG peak detection
2.  feature extraction: Folder containing code for feature extraction. Features are organized into csv files by segment type (eyes opened, eyes closed, and five minute segments)
    3.  Examples: Subfolder containing example ECG data, extracted peaks, and an example notebook

**Workflow**
1. Process raw ECG data through r-deco and export results to csv (R-Deco adds an extra sheet, so you will have to remove it)
2. Remove biologically improbable (heartrates less than 25)/incorrectly detected rr-intervals
3. Complete 1 and 2 for all subjects within a segment type
4. Run feature extraction code

**Requirements** 
Matlab (Signal processing toolbox)
Python (NumPy, Pandas, AntroPy)